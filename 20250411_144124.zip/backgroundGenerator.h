#pragma once
#include "LaserTurtleWindow.h"

void drawBackground(LTWindow& window);