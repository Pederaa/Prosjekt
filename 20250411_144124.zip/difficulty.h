enum class difficulty {
    barneskole,
    videregående,
    TDT4102,
};