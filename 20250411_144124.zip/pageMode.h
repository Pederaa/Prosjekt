#pragma once
enum class pageMode {
    frontpage,
    settingDifficulty,
    playing,
    credits
};