#pragma once
#include "AnimationWindow.h"
#include "LaserTurtleWindow.h"

void drawTypingScreen(LTWindow& window, std::string& c);
