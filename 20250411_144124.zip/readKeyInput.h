#pragma once
#include "AnimationWindow.h"

void getCharInput(LTWindow& window, std::string& c);